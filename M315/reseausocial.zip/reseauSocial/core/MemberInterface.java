package reseauSocial.core;

public interface MemberInterface {


	public int getAge();

	public String getDescription();

	public String ident();
}
