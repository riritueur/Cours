package facebookGhost;

public interface Event {

}
