package grapheX;

public class SommetValue {
  Sommet s;
  int valeur;
  
  SommetValue(Sommet ss, int vv){
    s = ss;
    valeur = vv;
  }
}
